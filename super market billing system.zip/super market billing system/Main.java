// Main.java
public class Main {
    public static void main(String[] args) {
        SupermarketApp app = new SupermarketApp();
        app.start();
    }
}
